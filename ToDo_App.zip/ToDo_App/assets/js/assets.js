//check off specific todos by clicking
$("ul").on("click", "li", function(){
	//check if li is grey, turn it black, else grey
	$(this).toggleClass("completed");
});

//click on 'X' to delete Todo

$("ul").on("click", "span",  function(event){
	$(this).parent().fadeOut(500, function(){//parent refers to the li
		$(this).remove();//this will refer to the li,as we are using parent()
	});
	event.stopPropagation();//this will stop the event bubbling up
});

$("input[type = 'text']").keypress(function(event){
	if(event.which === 13)//if we press enter
	{
		//grabbing new todo text from input
		var todoText = $(this).val();
		$(this).val("");//clearing the input text
		//create a new li and add to ul
		$("ul").append("<li><span><i class = 'fa fa-trash'></i></span> " + todoText +"</li>");
		
	}
});
 
$(".fa-plus").click(function(){
	$("input[type = 'text']").fadeToggle();
});